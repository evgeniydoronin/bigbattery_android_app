package com.clj.fastble.data;



public class BleWriteState {

    public static final int DATA_WRITE_SINGLE = 1;
}
