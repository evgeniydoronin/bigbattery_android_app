package com.zetarapower.monitor.bluetooth

import java.util.*

data class ZetaraBleUUID(val primaryServiceUUID: UUID, val writeUUID: UUID, val notifyUUID: UUID)