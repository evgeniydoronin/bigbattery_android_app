package com.zetarapower.monitor.logic

/**
 * Created by juqiu.lt on 10/27/22.
 */

interface BMSDataReadyCallback {
     fun bmsDataReady(bmsData: BMSData?)
}